#!/bin/bash
WORKSPACE="/var/lib/jenkins/workspace/GSIT_Alertas_Pruebas"
BRANCH="Dev_Sondas"
SERVICE_NAME="email_listener.service"

echo "🚀 Actualizando Email Listener..."
cd "$WORKSPACE" || { echo "❌ No se pudo acceder al workspace"; exit 1; }

sudo -u jenkins git fetch --all
sudo -u jenkins git checkout "$BRANCH"
sudo -u jenkins git pull origin "$BRANCH"

echo "🔄 Reiniciando servicio..."
sudo systemctl restart "$SERVICE_NAME"

echo "📊 Estado del servicio:"
sudo systemctl status "$SERVICE_NAME" --no-pager
